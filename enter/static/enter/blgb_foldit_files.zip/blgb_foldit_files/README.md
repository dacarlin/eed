Bagel
=====

Structures of beta-galactosidease B and associated scripts
